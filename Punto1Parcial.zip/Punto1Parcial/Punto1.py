MovimientoUsuario = input("Ingrese el movimiento: ")
LetrasPiezas = "pkbqnr"
LetrasTablero = "abcdefgh"
NumerosTablero = "12345678"
EsValido = False
if len(MovimientoUsuario) == 5:
    if MovimientoUsuario[0] in LetrasPiezas:
        if MovimientoUsuario[1] == "-" and MovimientoUsuario[2] == ">":
            if MovimientoUsuario[3] in LetrasPiezas:
                if MovimientoUsuario[4] in NumerosTablero:
                    EsValido = True
elif len(MovimientoUsuario) == 8:
    if MovimientoUsuario[0] in LetrasPiezas and MovimientoUsuario[1] in LetrasPiezas and MovimientoUsuario[2] in LetrasPiezas:
        if MovimientoUsuario[3:6] == " X ":
            if MovimientoUsuario[6] in LetrasPiezas:
                if MovimientoUsuario[7] in LetrasPiezas or MovimientoUsuario[7] in LetrasTablero:
                    EsValido = True
if EsValido:
    print("ACEPTA")
else:
    print("NO ACEPTA")
