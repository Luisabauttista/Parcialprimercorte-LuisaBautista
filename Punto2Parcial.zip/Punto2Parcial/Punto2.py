IdUsuario = input("Ingrese el ID: ")
TodasLetras = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
TodosNumeros = "0123456789"
EstadoActual = 0
EsPosible = True
if len(IdUsuario) == 0:
    EsPosible = False
else:
    for Caracter in IdUsuario:
        if EstadoActual == 0:
            if Caracter in TodasLetras:
                EstadoActual = 1
            else:
                EsPosible = False
                break
        elif EstadoActual == 1:
            if Caracter in TodasLetras or Caracter in TodosNumeros:
                EstadoActual = 1
            else:
                EsPosible = False
                break
if EsPosible and EstadoActual == 1:
    print("ACEPTA")
else:
    print("NO ACEPTA")
