#include <stdio.h>
#include <time.h>

int CalculoFibonacci(int NumeroN) {
    if (NumeroN < 2) {
        return NumeroN;
    }
    return CalculoFibonacci(NumeroN - 1) + CalculoFibonacci(NumeroN - 2);
}

int main() {
    int NumeroPrueba = 40;
    clock_t TiempoInicio = clock();
    
    printf("Calculando en C...\n");
    int ResultadoFinal = CalculoFibonacci(NumeroPrueba);
    
    clock_t TiempoFin = clock();
    double TiempoTotal = (double)(TiempoFin - TiempoInicio) / CLOCKS_PER_SEC;
    
    printf("Resultado: %d\n", ResultadoFinal);
    printf("Tiempo en C: %.4f segundos\n", TiempoTotal);
    
    return 0;
}
