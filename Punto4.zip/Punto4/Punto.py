import time

def CalculoFibonacci(NumeroN):
    if NumeroN < 2:
        return NumeroN
    return CalculoFibonacci(NumeroN - 1) + CalculoFibonacci(NumeroN - 2)

NumeroPrueba = 40
TiempoInicio = time.time()

print("Calculando en Python...")
ResultadoFinal = CalculoFibonacci(NumeroPrueba)

TiempoFin = time.time()
print(f"Resultado: {ResultadoFinal}")
print(f"Tiempo en Python: {TiempoFin - TiempoInicio:.4f} segundos")
